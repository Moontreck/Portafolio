// Animaciones al hacer scroll (WOW.js + Animate.css 4)
new WOW({ animateClass: 'animate__animated' }).init();

// Galería FancyBox: muestra la imagen en tamaño original
$('[data-fancybox="portafolio"]').fancybox({
  loop: true,
  buttons: ['zoom', 'slideShow', 'fullScreen', 'close'],
  animationEffect: 'zoom-in-out'
});

// Cierra el menú móvil al elegir una sección
document.querySelectorAll('#menu .nav-link').forEach(function (enlace) {
  enlace.addEventListener('click', function () {
    var menu = document.getElementById('menu');
    if (menu.classList.contains('show')) {
      bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });
});
